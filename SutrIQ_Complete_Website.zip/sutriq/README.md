# SutrIQ — Data Intelligence & BI Consulting Website

## 🚀 Live Features
- ✅ Multi-page website (Home, About, Services, Projects, Contact)
- ✅ User Signup / Login (Firebase Auth)
- ✅ Real-time Community Chat (Firebase Realtime DB)
- ✅ Image sharing in chat (Firebase Storage)
- ✅ Block/Unblock users
- ✅ Admin panel (nitishbharti04@gmail.com only)
- ✅ Hire form → Email + WhatsApp + Google Sheets
- ✅ User data stored in Firestore + Google Sheets

## ⚙️ Setup Steps

### 1. Firebase Setup (5 minutes)
1. Go to https://console.firebase.google.com
2. Create new project → "sutriq"
3. Enable Authentication → Email/Password
4. Enable Firestore Database → Start in test mode
5. Enable Realtime Database → Start in test mode
6. Enable Storage → Start in test mode
7. Click Project Settings → Your apps → Web app → Copy firebaseConfig

### 2. Update Config in index.html
Search for `YOUR_API_KEY` and replace all Firebase values with your real ones.

### 3. EmailJS Setup (3 minutes)
1. Go to https://emailjs.com → Free account
2. Add Email Service → Gmail → connect nitishbharti04@gmail.com
3. Create Email Template with these variables:
   {{from_name}}, {{from_email}}, {{from_phone}}, {{company}},
   {{service}}, {{budget}}, {{description}}
4. Copy Public Key → replace `YOUR_EMAILJS_PUBLIC_KEY`
5. Copy Service ID → replace `service_sutriq`
6. Copy Template ID → replace `template_hire`

### 4. Google Sheets Webhook (5 minutes)
1. Create a Google Sheet with columns:
   Type | Name | Email | Phone | Company | Service | Budget | Description | Date
2. Open Extensions → Apps Script → paste this code:
```javascript
function doPost(e) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  const data = JSON.parse(e.postData.contents);
  sheet.appendRow([
    data.type, data.name, data.email, data.phone,
    data.company||"", data.service||"", data.budget||"",
    data.description||"", new Date().toISOString()
  ]);
  return ContentService.createTextOutput("OK");
}
```
3. Deploy → Web App → Anyone → Copy URL
4. Replace `YOUR_GOOGLE_APPS_SCRIPT_URL` in index.html

### 5. Deploy to GitHub Pages
```bash
git init
git add .
git commit -m "SutrIQ website launch 🚀"
git remote add origin https://github.com/YOUR_USERNAME/sutriq.git
git push -u origin main
```
Then: GitHub repo → Settings → Pages → Source: main branch → Save
Your site: https://YOUR_USERNAME.github.io/sutriq

## 📁 File Structure
```
sutriq/
├── index.html      ← Main website (all pages)
├── css/main.css    ← Global styles
├── js/app.js       ← Firebase utilities
├── js/firebase-config.js  ← Config (update this!)
├── README.md
└── .gitignore
```

## 🔐 Admin Access
Only nitishbharti04@gmail.com has admin access.
Login → Nav shows "Admin" button → Full user management + chat monitoring.

## 📞 Contact
Email: nitishbharti04@gmail.com | Phone: +91 98438 69606
